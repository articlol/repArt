create definer = root@localhost trigger write_log
  before INSERT
  on users
  for each row
begin
	insert into user_log (date) values (now());
end;

