create
  definer = root@localhost procedure add_users(IN nameadd char(60), IN ageadd int, IN emailadd char(60))
begin
	insert into users (name, age, email) values (nameadd, ageadd, emailadd);
end;

